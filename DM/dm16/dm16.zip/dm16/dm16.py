
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# NOM :
# Prénom :
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

"""DM n°16."""

import math
import numpy as np
import matplotlib.pyplot as plt

question_00 = """
-- Mettre entre triple guillements vos requêtes SQL.
-- On peut très bien aller à la ligne dans un guillement triple en Python.
SELECT ...
FROM ...
WHERE ...
"""

question_01 = """ """
question_02 = """ """
question_03 = """ """
question_04 = """ """
question_05 = """ """
question_06 = """ """
question_07 = """ """
question_08 = """ """
question_09 = """ """
question_10 = """ """
question_11 = """ """
question_12 = """ """
question_13 = """ """
question_14 = """ """
question_15 = """ """
question_16 = """ """
question_17 = """ """
question_18 = """ """
question_19 = """ """
question_20 = """ """
question_21 = """ """
question_22 = """ """
question_23 = """ """
question_24 = """ """
question_25 = """ """
question_26 = """ """
question_27 = """ """
question_28 = """ """
question_29 = """ """
question_30 = """ """
question_31 = """ """
question_32 = """ """
question_33 = """ """
question_34 = """ """
question_35 = """ """
